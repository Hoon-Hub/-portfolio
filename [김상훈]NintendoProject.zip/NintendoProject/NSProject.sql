-- ȸ�� ��� ����
create sequence NS_member_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;
    
create table NS_member(
member_num number primary key,
id varchar2(30) not null,
pw varchar2(30) not null,
name varchar2(20) not null,
email varchar2(50) not null,
tel1 varchar2(10) not null,
tel2 varchar2(20) not null,
tel3 varchar2(20) not null,
address varchar2(500) not null,
item_name varchar2(100)
);
select * from Ns_member;

--��ǰ DB
select id from Ns_member where id='Admin';
create sequence NS_item_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;
    
    
create table NS_item(
 item_num number,
 item_name varchar2(100)  primary key,
 item_img varchar2(100),
 item_readCount number, -- ��ǰ Ŭ�� ��ȸ�� -> ��ǰ �α��
 item_price number,
 item_content varchar2(50) not null,
 category varchar2(20) not null
);

select * from NS_item;
insert into NS_item values(
    1, 'First Product', './images/switch_lite.png', 0, 19520, 'ù �� ° ������ �ۼ��մϴ�','model'
);
insert into NS_item values(
    2, 'Second Product', './images/switch_lite3.png', 0, 1230, '�� �� ° ������ �ۼ��մϴ�','model'
);
insert into NS_item values(
    3, 'Third Product', './images/switch_lite2.png', 0, 15320, '�� �� ° ������ �ۼ��մϴ�','model'
);
insert into NS_item values(
    4, 'Fourth Product', './images/switch_lite4.png', 0, 121320, '�� �� ° ������ �ۼ��մϴ�','model'
);
insert into NS_item values(
    5, 'Fiveth Product', './images/switch1.png', 0, 8420, '�ټ� �� ° ������ �ۼ��մϴ�','game'
);
insert into NS_item values(
    6, 'Sixth Product', './images/switch2.png', 0, 35480, '���� �� ° ������ �ۼ��մϴ�','game'
);
insert into NS_item values(
    7, 'Seventh Product', './images/switch3.png', 0, 121320, '�ϰ� �� ° ������ �ۼ��մϴ�','game'
);
insert into NS_item values(
    8, '�𿩺��� ������ ��', './images/game1.jpg', 0, 60200, '��� �� ����! ��! ������ ��','game'
);
insert into NS_item values(
    9, '��ƺ���3 ���ٵ�', './images/game2.jpg', 0, 50000, '��ƺ���3 ���ٵ� ','game'
);
insert into NS_item values(
    10, '������ ����', './images/game3.jpg', 0, 48000, '������ ���� - �����մϴ�.','game'
);
insert into NS_item values(
    11, '��Ʈ����', './images/game4.jpg', 0, 32000, '��Ʈ���� ����','game'
);
delete from NS_item where item_num = 9;
drop table NS_item;
select * from NS_item;
commit;
alter table NS_item add category varchar2(20);

 -- �������� DB
create sequence NS_notice_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;

create table NS_notice(
 notice_num number primary key,
 id varchar2(20) not null,
 notice_subject varchar2(50) not null,
 notice_reg_date Date,
 notice_ref  number,
  notice_re_step number,
 notice_readCount number,
 notice_content varchar2(1000) not null
);
select * from NS_notice where notice_num=24;
select * from NS_notice order by notice_num desc;
insert into NS_notice values(
    1, 'Admin', 'ù��° �������� ����', sysdate, 0, 'ù ��° �������� �����Դϴ�.'
);
drop table NS_notice;
alter table NS_notice modify (notice_content varchar2(1000));
alter table NS_notice add ( notice_re_step number);
select * from NS_notice;
desc NS_notice;
commit;

--------------------------------------------------------------------------------
--Ŀ�´�Ƽ DB
create sequence NS_community_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;

create table NS_community(
 com_num number primary key,
 id varchar2(20) not null,
 com_subject varchar2(50) not null,
 com_reg_date Date,
 com_ref  number,
 com_readCount number,
 com_content varchar2(1000) not null,
 com_re_step number,
 com_re_level number
);
 drop table NS_community;
 select * from ns_community;
 delete from NS_community;
 ALTER TABLE NS_community drop column comment_time;
 desc ns_community;
 commit;
--QA--------------------------------------------------------------------
create sequence NS_qa_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;


create table NS_qa(
 qa_num number primary key,
 id varchar2(20) not null,
 qa_subject varchar2(50) not null,
 qa_reg_date Date,
 qa_readCount number,
 qa_ref  number,
 qa_re_step number,
 qa_re_level number,
 qa_content varchar2(1000) not null
);

select * from NS_qa;

--��ٱ���------------------------------------------------------------------
create sequence NS_bucket_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;
    
create table NS_bucket(
bucket_num number primary key,
id varchar2(30) not null,
item_name varchar2(100) not null,
amount number,
item_img varchar2(100),
item_price number,
sum number
);
alter table NS_bucket modify (item_name varchar2(100));

delete from NS_bucket where id = 'null';
select * from ns_bucket;
select sum(sum) from NS_bucket where id='Admin';
commit;
--Ŀ�´�Ƽ -> ���------------------------------------------------
create sequence NS_comment_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;
    
create table NS_comment(
 comment_num number primary key,
 com_num number,
 id varchar2(20),
 comment_ref  number,
 comment_content varchar2(500) not null,
 comment_time Date,
 comment_re_step number,
 comment_re_level number
);
insert into NS_comment values(
    1, 8, 'Admin', 1, 'asdasdasd', sysdate, 1, 1
);
select * from ns_community;
select * from ns_comment;
commit;

--���� ����db----------------------------------------------------------------
create sequence NS_Calculate_seq
    start with 1
    increment by 1
    minvalue 1
    maxvalue 10000;
    
create table NS_calculate(
cal_num number primary key,
id varchar2(30) not null,
item_name varchar2(100) not null,
item_img varchar2(100),
item_price number not null,
sum number not null,
cal_method varchar2(10) not null
);

select * from ns_calculate;
