function Logout () {
	//	document.getElementById("id").value = null;
	alert('로그아웃 되었습니다.');
	location.href = "Main.jsp";
}

function inNumber () {
	if (event.keyCode < 48 || event.keyCode > 57) {
		event.returnValue = false;
	}
}
