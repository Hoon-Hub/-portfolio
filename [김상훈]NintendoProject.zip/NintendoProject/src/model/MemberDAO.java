package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDAO {

	Connection conn; // DB연결(ID, Password, url)
	PreparedStatement pstmt; // SQL 실행
	ResultSet rs; // 실행된 SQL결과를 저장하고 출력함

	public void getConnection() {

		try {
			Context initctx = new InitialContext(); // 개발환경상의 가상의 경로
			Context envctx = (Context) initctx.lookup("java:comp/env"); // 데이터베이스에 접근
			DataSource ds = (DataSource) envctx.lookup("jdbc/oracle"); //
			conn = ds.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	   public void insertBoardMember(BoardBean bean) {
		      getConnection();
		      String sql = "insert into NS_member values(NS_member_seq.nextval,?,?,?,?,?,?,?,?,?)";
		      try {

		         PreparedStatement pstmt = conn.prepareStatement(sql);

		         pstmt.setString(1, bean.getId());
		         pstmt.setString(2, bean.getPw());
		         pstmt.setString(3, bean.getName());
		         pstmt.setString(4, bean.getEmail());
		         pstmt.setString(5, bean.getTel1());
		         pstmt.setString(6, bean.getTel2());
		         pstmt.setString(7, bean.getTel3());
		         pstmt.setString(8, bean.getAddress());
		         pstmt.setString(9, bean.getItem_name());

		         pstmt.executeUpdate();
		         conn.close();

		      } catch (Exception e) {
		         e.printStackTrace();
		      }
		   }
	public int getMember(String id, String pw) {
		int result = 0; // 처음이면 회원 없음.

		getConnection(); // DB연결

		try {
			String sql = "select count(*) from NS_member where id=?and pw=?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.setString(2, pw);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				result = rs.getInt(1); // 0또는 1 값이 저장됩니다.
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	public int IdCheck(String id) {
		int rst = 0;
		getConnection();

		try {
			String sql = "select id from NS_member where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				rst = 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rst;
	}

	public String getPw(String id) {
		getConnection();
		String pw = "";
		try {
			String sql = "select pw from NS_member where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				pw = rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return pw;
	}

	public BoardBean getOneUpdateMember(String id) {
		BoardBean bean = new BoardBean();
		getConnection();

		try {
			String sql = "select * from NS_member where id =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				bean.setMember_num(rs.getInt(1)); // sequence number
				bean.setId(rs.getString(2));
				bean.setPw(rs.getString(3));
				bean.setName(rs.getString(4));
				bean.setEmail(rs.getString(5));
				bean.setTel1(rs.getString(6));
				bean.setTel2(rs.getString(7));
				bean.setTel3(rs.getString(8));
				bean.setAddress(rs.getString(9));
			}

			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return bean;
	}

	public void updateMember(BoardBean bean) {
		getConnection();

		try {
			String sql = "update NS_member set name=?, email=?, tel1 =?, tel2=?, tel3=?, address=? where id =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bean.getName());
			pstmt.setString(2, bean.getEmail());
			pstmt.setString(3, bean.getTel1());
			pstmt.setString(4, bean.getTel2());
			pstmt.setString(5, bean.getTel3());
			pstmt.setString(6, bean.getAddress());
			pstmt.setString(7, bean.getId());

			pstmt.executeUpdate();

			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	  //멤버 삭제
	   public void deleteMember(String id) {

		      getConnection();

		      try {
		         String sql = "delete from NS_member where id=?";

		         pstmt = conn.prepareStatement(sql);

		         pstmt.setString(1, id);

		         pstmt.executeUpdate();

		         conn.close();

		      } catch (Exception e) {
		         e.printStackTrace();

		      }
		   }
	   
	
	
}
