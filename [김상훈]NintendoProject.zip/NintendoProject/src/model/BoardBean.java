package model;

public class BoardBean {
	// 회원정보 항목
	private int member_num;
	// 공지사항 db와 공용
	private String id;
	private String pw;
	private String name;
	private String email;
	private String tel1;
	private String tel2;
	private String tel3;
	private String address;
	// 상품 db랑공용
	private String item_name;

	// 상품 db
	private int item_num;
	private String Item_img; //사진경로
	private int item_readCount;
	private int item_price; 
	private String item_content;
	private String Category;
	
	// 공지사항 db
	private int notice_num;
	private String notice_subject;
	private String notice_reg_date;
	private int notice_readCount;
	private String notice_content;
	private int notice_re_step;
	private int notice_ref;

	// 이벤트 db
	private int event_num;
	private String event_title;
	private String event_reg_date;
	private int event_readCount;
	private String event_content;

	// 커뮤니티 db
	private int com_num;
	private String com_subject;
	private String com_reg_date;
	private int com_ref;
	private int com_readCount;
	private String com_content;
	private String comment_;
	private String comment_time;
	private int Com_re_step;
	private int Com_re_level;
	
	// QA db
	private int qa_num;
	private String qa_subject;
	private String qa_reg_date;
	private int qa_readCount;
	private int qa_ref;
	private int qa_re_step;
	private int qa_re_level;
	private String qa_content;

	//장바구니 db
	private int bucket_num;
	private int amount;
	private int sum;
	
	//결제 db
	private int cal_num;
	private int cal_method;
	
	//댓글 db
	 private int comment_num;
	 private int comm_num;
	 private int comment_ref;
	 private String  comment_content;
	 private int comment_re_step;
	 private int comment_re_level;
	
	public int getMember_num() {
		return member_num;
	}
	public void setMember_num(int member_num) {
		this.member_num = member_num;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTel1() {
		return tel1;
	}
	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}
	public String getTel2() {
		return tel2;
	}
	public void setTel2(String tel2) {
		this.tel2 = tel2;
	}
	public String getTel3() {
		return tel3;
	}
	public void setTel3(String tel3) {
		this.tel3 = tel3;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public int getItem_num() {
		return item_num;
	}
	public void setItem_num(int item_num) {
		this.item_num = item_num;
	}
	public int getItem_readCount() {
		return item_readCount;
	}
	public void setItem_readCount(int item_readCount) {
		this.item_readCount = item_readCount;
	}
	public int getItem_price() {
		return item_price;
	}
	public void setItem_price(int item_price) {
		this.item_price = item_price;
	}
	public String getItem_content() {
		return item_content;
	}
	public void setItem_content(String item_content) {
		this.item_content = item_content;
	}
	public int getNotice_num() {
		return notice_num;
	}
	public void setNotice_num(int notice_num) {
		this.notice_num = notice_num;
	}
	public String getNotice_subject() {
		return notice_subject;
	}
	public void setNotice_subject(String notice_subject) {
		this.notice_subject = notice_subject;
	}
	public String getNotice_reg_date() {
		return notice_reg_date;
	}
	public void setNotice_reg_date(String notice_reg_date) {
		this.notice_reg_date = notice_reg_date;
	}
	public int getNotice_readCount() {
		return notice_readCount;
	}
	public void setNotice_readCount(int notice_readCount) {
		this.notice_readCount = notice_readCount;
	}
	public String getNotice_content() {
		return notice_content;
	}
	public void setNotice_content(String notice_content) {
		this.notice_content = notice_content;
	}
	public int getEvent_num() {
		return event_num;
	}
	public void setEvent_num(int event_num) {
		this.event_num = event_num;
	}
	public String getEvent_title() {
		return event_title;
	}
	public void setEvent_title(String event_title) {
		this.event_title = event_title;
	}
	public String getEvent_reg_date() {
		return event_reg_date;
	}
	public void setEvent_reg_date(String event_reg_date) {
		this.event_reg_date = event_reg_date;
	}
	public int getEvent_readCount() {
		return event_readCount;
	}
	public void setEvent_readCount(int event_readCount) {
		this.event_readCount = event_readCount;
	}
	public String getEvent_content() {
		return event_content;
	}
	public void setEvent_content(String event_content) {
		this.event_content = event_content;
	}
	public int getCom_num() {
		return com_num;
	}
	public void setCom_num(int com_num) {
		this.com_num = com_num;
	}
	public String getCom_subject() {
		return com_subject;
	}
	public void setCom_subject(String com_subject) {
		this.com_subject = com_subject;
	}
	public String getCom_reg_date() {
		return com_reg_date;
	}
	public void setCom_reg_date(String com_reg_date) {
		this.com_reg_date = com_reg_date;
	}
	public int getCom_ref() {
		return com_ref;
	}
	public void setCom_ref(int com_ref) {
		this.com_ref = com_ref;
	}
	public int getCom_readCount() {
		return com_readCount;
	}
	public void setCom_readCount(int com_readCount) {
		this.com_readCount = com_readCount;
	}
	public String getCom_content() {
		return com_content;
	}
	public void setCom_content(String com_content) {
		this.com_content = com_content;
	}
	public int getQa_num() {
		return qa_num;
	}
	public void setQa_num(int qa_num) {
		this.qa_num = qa_num;
	}
	public String getQa_subject() {
		return qa_subject;
	}
	public void setQa_subject(String qa_subject) {
		this.qa_subject = qa_subject;
	}
	public String getQa_reg_date() {
		return qa_reg_date;
	}
	public void setQa_reg_date(String qa_reg_date) {
		this.qa_reg_date = qa_reg_date;
	}
	public int getQa_readCount() {
		return qa_readCount;
	}
	public void setQa_readCount(int qa_readCount) {
		this.qa_readCount = qa_readCount;
	}
	public int getQa_ref() {
		return qa_ref;
	}
	public void setQa_ref(int qa_ref) {
		this.qa_ref = qa_ref;
	}
	public int getQa_re_step() {
		return qa_re_step;
	}
	public void setQa_re_step(int qa_re_step) {
		this.qa_re_step = qa_re_step;
	}
	public int getQa_re_level() {
		return qa_re_level;
	}
	public void setQa_re_level(int qa_re_level) {
		this.qa_re_level = qa_re_level;
	}
	public String getQa_content() {
		return qa_content;
	}
	public void setQa_content(String qa_content) {
		this.qa_content = qa_content;
	}
	public String getComment_time() {
		return comment_time;
	}
	public void setComment_time(String comment_time) {
		this.comment_time = comment_time;
	}
	public String getItem_img() {
		return Item_img;
	}
	public void setItem_img(String item_img) {
		Item_img = item_img;
	}
	public int getCom_re_step() {
		return Com_re_step;
	}
	public void setCom_re_step(int com_re_step) {
		Com_re_step = com_re_step;
	}
	public int getCom_re_level() {
		return Com_re_level;
	}
	public void setCom_re_level(int com_re_level) {
		Com_re_level = com_re_level;
	}
	public int getBucket_num() {
		return bucket_num;
	}
	public void setBucket_num(int bucket_num) {
		this.bucket_num = bucket_num;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public String getComment_() {
		return comment_;
	}
	public void setComment_(String comment_) {
		this.comment_ = comment_;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public int getComment_num() {
		return comment_num;
	}
	public void setComment_num(int comment_num) {
		this.comment_num = comment_num;
	}
	public int getComm_num() {
		return comm_num;
	}
	public void setComm_num(int comm_num) {
		this.comm_num = comm_num;
	}
	public int getComment_ref() {
		return comment_ref;
	}
	public void setComment_ref(int comment_ref) {
		this.comment_ref = comment_ref;
	}
	public String getComment_content() {
		return comment_content;
	}
	public void setComment_content(String comment_content) {
		this.comment_content = comment_content;
	}
	public int getComment_re_step() {
		return comment_re_step;
	}
	public void setComment_re_step(int comment_re_step) {
		this.comment_re_step = comment_re_step;
	}
	public int getComment_re_level() {
		return comment_re_level;
	}
	public void setComment_re_level(int comment_re_level) {
		this.comment_re_level = comment_re_level;
	}
	public int getNotice_re_step() {
		return notice_re_step;
	}
	public void setNotice_re_step(int notice_re_step) {
		this.notice_re_step = notice_re_step;
	}
	public int getNotice_ref() {
		return notice_ref;
	}
	public void setNotice_ref(int notice_ref) {
		this.notice_ref = notice_ref;
	}
	public int getCal_method() {
		return cal_method;
	}
	public void setCal_method(int cal_method) {
		this.cal_method = cal_method;
	}
	public int getCal_num() {
		return cal_num;
	}
	public void setCal_num(int cal_num) {
		this.cal_num = cal_num;
	}


}
