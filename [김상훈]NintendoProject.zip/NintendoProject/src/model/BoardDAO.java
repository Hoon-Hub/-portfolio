package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class BoardDAO {

	Connection conn; // DB연결(ID, Password, url)
	PreparedStatement pstmt; // SQL 실행
	ResultSet rs; // 실행된 SQL결과를 저장하고 출력함

	// 데이터 베이스에 연결해주는 메서드 호출
	public void getConnection() {

		try {
			Context initctx = new InitialContext(); // 개발환경상의 가상의 경로

			Context envctx = (Context) initctx.lookup("java:comp/env"); // 데이터베이스에 접근
			DataSource ds = (DataSource) envctx.lookup("jdbc/oracle"); //
			conn = ds.getConnection();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

// 메인화면 - 모든 리스트 불러오기
	public Vector<BoardBean> getAllItem() {

		Vector<BoardBean> v = new Vector<BoardBean>();

		BoardBean bean = null;

		getConnection();
		try {
			String sql = "select * from NS_item order by Item_readCount desc";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				bean = new BoardBean();

				bean.setItem_num(rs.getInt(1));
				bean.setItem_name(rs.getString(2));
				bean.setItem_img(rs.getString(3));
				bean.setItem_readCount(rs.getInt(4));
				bean.setItem_price(rs.getInt(5));
				bean.setItem_content(rs.getString(6));
				bean.setCategory(rs.getString(7));

				v.add(bean);
			}
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;

	}

	// 메인화면 - 상품 상세페이지
	public BoardBean getItemInfo(String item_name) {
		BoardBean bean = new BoardBean();
		getConnection();

		try {
			String readsql = "update NS_item set item_readCount = item_readCount + 1 where item_name=?";
			pstmt = conn.prepareStatement(readsql);
			pstmt.setString(1, item_name);
			pstmt.executeUpdate();

			String sql = "select * from NS_item where item_name=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, item_name);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				bean.setItem_num(rs.getInt(1));
				bean.setItem_name(rs.getString(2));
				bean.setItem_img(rs.getString(3));
				bean.setItem_readCount(rs.getInt(4));
				bean.setItem_price(rs.getInt(5));
				bean.setItem_content(rs.getString(6));
			}
			conn.close();
		} catch (

		Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	// 공지사항
	public Vector<BoardBean> getAllNotice() {

		Vector<BoardBean> v = new Vector<BoardBean>();
		getConnection();

		try {
			String sql = "select * from NS_notice order by notice_ref desc, notice_re_step asc";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean bean = new BoardBean();

				bean.setNotice_num(rs.getInt(1));
				bean.setId(rs.getString(2));
				bean.setNotice_subject(rs.getString(3));
				bean.setNotice_reg_date(rs.getDate(4).toString());
				bean.setNotice_ref(rs.getInt(5));
				bean.setNotice_re_step(rs.getInt(6));
				bean.setNotice_readCount(rs.getInt(7));
				bean.setNotice_content(rs.getString(8));

				v.add(bean);
			}
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}

	// 공지사항 세부
	public BoardBean getNoticeInfo(int notice_num) {
		BoardBean nbean = new BoardBean();
		getConnection();

		try {
			String readsql = "update NS_notice set notice_readCount = notice_readCount + 1 where notice_num=?";
			pstmt = conn.prepareStatement(readsql);
			pstmt.setInt(1, notice_num);
			pstmt.executeUpdate();

			String sql = "select * from NS_notice where notice_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_num);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				nbean.setNotice_num(rs.getInt(1));
				nbean.setId(rs.getString(2));
				nbean.setNotice_subject(rs.getString(3));
				nbean.setNotice_reg_date(rs.getDate(4).toString());
				nbean.setNotice_ref(rs.getInt(5));
				nbean.setNotice_ref(rs.getInt(6));
				nbean.setNotice_readCount(rs.getInt(7));
				nbean.setNotice_content(rs.getString(8));
			}
			conn.close();
		} catch (

		Exception e) {
			e.printStackTrace();
		}
		return nbean;
	}

	// 공지사항 수정1
	public BoardBean getOneNoticeUpdate(int notice_num) {
		BoardBean bean = new BoardBean();
		getConnection();

		try {
			String sql = "select * from NS_notice where notice_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice_num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				bean.setNotice_num(rs.getInt(1));// sequence number
				bean.setId(rs.getString(2));
				bean.setNotice_subject(rs.getString(3));
				bean.setNotice_reg_date(rs.getDate(4).toString());
				bean.setNotice_ref(rs.getInt(5));
				bean.setNotice_re_step(rs.getInt(6));
				bean.setNotice_readCount(rs.getInt(7));
				bean.setNotice_content(rs.getString(8));

			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bean;
	}

	// 공지사항 수정
	public void NoticeUpdate(BoardBean bean) {
		getConnection();

		try {
			String sql = "update NS_notice set notice_subject=?, notice_content=? where notice_num=?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, bean.getNotice_subject());
			pstmt.setString(2, bean.getNotice_content());
			pstmt.setInt(3, bean.getNotice_num());

			pstmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 공지사항 개수 카운트
	public int getAllcount() {
		getConnection();

		int count = 0;
		try {
			String sql = "select count(*) from NS_notice";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				count = rs.getInt(1);
			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

	// 공지사항 페이지 카운트
	public Vector<BoardBean> getAllBoard(int start, int end) {

		Vector<BoardBean> v = new Vector<BoardBean>();

		getConnection();

		try {
			String sql = "select * from (select A.*, Rownum Rnum from (select * from NS_notice order by notice_ref desc, notice_re_step asc)A) where Rnum >= ? and Rnum <=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				BoardBean bean = new BoardBean();
				bean.setNotice_num(rs.getInt(1));// sequence number
				bean.setId(rs.getString(2));
				bean.setNotice_subject(rs.getString(3));
				bean.setNotice_reg_date(rs.getDate(4).toString());
				bean.setNotice_ref(rs.getInt(5));
				bean.setNotice_re_step(rs.getInt(6));
				bean.setNotice_readCount(rs.getInt(7));
				bean.setNotice_content(rs.getString(8));

				v.add(bean);
			}

			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;
	}

	public void NoticeDelete(int notice_num) {
		getConnection();
		try {
			String sql = "delete from NS_notice where notice_num = ?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, notice_num);
			pstmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 공지사항 작성
	public void NoticeWrite(BoardBean nbean) {
		getConnection();
		int notice_ref = 0;
		int notice_re_step = 1;

		try {
			String refsql = "select max(notice_ref) from NS_notice";
			pstmt = conn.prepareStatement(refsql);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				notice_ref = rs.getInt(1) + 1; // 최대값에 +1을 더하여 글그룹 설정
			}
			String sql = "insert into NS_Notice values(NS_notice_seq.nextval,'Admin',?,sysdate,?,?,0,?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, nbean.getNotice_subject());
			pstmt.setInt(2, notice_ref);
			pstmt.setInt(3, notice_re_step);
			pstmt.setString(4, nbean.getNotice_content());

			pstmt.executeUpdate();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// 상품 한가지만 결제
	public BoardBean OneAccount(String item_name) {
		BoardBean bean = new BoardBean();
		getConnection();

		try {

			String sql = "select * from NS_item where item_name=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, item_name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setItem_num(rs.getInt(1)); // sequence number
				bean.setItem_name(rs.getString(2));
				bean.setItem_img(rs.getString(3));
				bean.setItem_price(rs.getInt(5));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bean;
	}

	// 장바구니 담기
	public void insertBucket(BoardBean bean) {
		getConnection();
		String sql = "insert into NS_bucket values(NS_member_seq.nextval,?,?,?,?,?,?)";
		try {

			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, bean.getId());
			pstmt.setString(2, bean.getItem_name());
			pstmt.setInt(3, bean.getAmount());
			pstmt.setString(4, bean.getItem_img());
			pstmt.setInt(5, bean.getItem_price());
			pstmt.setInt(6, bean.getSum());

			pstmt.executeUpdate();
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// 아이디별 장바구니 목록 보기
	public Vector<BoardBean> showBucket(String id) {

		Vector<BoardBean> v = new Vector<BoardBean>();

		BoardBean bean = null;

		getConnection();
		try {
			String sql = "select * from NS_bucket where id =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				bean = new BoardBean();

				bean.setBucket_num(rs.getInt(1));
				bean.setId(rs.getString(2));
				bean.setItem_name(rs.getString(3));
				bean.setAmount(rs.getInt(4));
				bean.setItem_img(rs.getString(5));
				bean.setItem_price(rs.getInt(6));
				bean.setSum(rs.getInt(7));

				v.add(bean);
			}
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;

	}

	public Vector<BoardBean> Category(String Category) {

		Vector<BoardBean> v = new Vector<BoardBean>();

		BoardBean bean = null;

		getConnection();
		try {

			String sql = "select * from NS_item where Category =?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, Category);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				bean = new BoardBean();

				bean.setItem_num(rs.getInt(1));
				bean.setItem_name(rs.getString(2));
				bean.setItem_img(rs.getString(3));
				bean.setItem_readCount(rs.getInt(4));
				bean.setItem_price(rs.getInt(5));
				bean.setItem_content(rs.getString(6));
				bean.setCategory(rs.getString(7));

				v.add(bean);
			}
			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return v;

	}

//장바구니 화면에서 total 가격 불러오기
	public int BucketTotal(String id) {
		getConnection();
		int total = 0;
		try {
			String sql = "select sum(sum) from NS_bucket where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				total = rs.getInt(1);
			}
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return total;
	}

//장바구니 화면에서 아이템 한 개 삭제
	public void DeleteOneBucket(int bucket_num) {
		getConnection();
		try {
			String dsql = "delete from NS_Bucket where bucket_num = ?";
			pstmt = conn.prepareStatement(dsql);

			pstmt.setInt(1, bucket_num);
			pstmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//아이템 전체 삭제
	public void BucketAllDelete(String id) {
		getConnection();
		try {
			String sql = "delete from NS_bucket where id = ?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, id);
			pstmt.executeUpdate();

			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//결제 내역 저장	
	public void SaveCalculate(BoardBean bean, String id) {
		getConnection();
		try {
			String dsql = "delete from NS_calculate where id = ?";
			pstmt = conn.prepareStatement(dsql);

			pstmt.setString(1, id);
			pstmt.executeUpdate();
			
			
			String sql = "insert into NS_calculate values(NS_Calculate_seq.nextval, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, bean.getId());
			pstmt.setString(2, bean.getItem_name());
			pstmt.setString(3, bean.getItem_img());
			pstmt.setInt(4, bean.getItem_price());
			pstmt.setInt(5, bean.getSum());
			pstmt.setInt(6, bean.getCal_method());

			pstmt.executeUpdate();

			conn.close();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	//결제 내역 출력
	public BoardBean getSavedCalculate(String id) {
		BoardBean bean = new BoardBean();
		getConnection();

		try {
			String sql = "select * from NS_calculate where id=? order by cal_num desc";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				bean.setCal_num(rs.getInt(1));
				bean.setId(rs.getString(2));
				bean.setItem_name(rs.getString(3));
				bean.setItem_img(rs.getString(4));
				bean.setItem_price(rs.getInt(5));
				bean.setSum(rs.getInt(6));
				bean.setCal_method(rs.getInt(7)); //value=1,2,3
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bean;
	}
	
//QA---------------------------------------------------------------------------------------------
		public void insertQA(BoardBean bean) {
			getConnection();

			int qa_ref = 0; // 글그룹 = 쿼리를 실행하여 가장 큰 ref 값을 가져오고 +1을 더해줍니다.
			int qa_re_step = 1; // 새 글 일 때 = 부모글이기에
			int qa_re_level = 1;
			try {
				String refsql = "select max(qa_ref) from NS_qa";
				pstmt = conn.prepareStatement(refsql);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					qa_ref = rs.getInt(1) + 1; // 최대값에 +1을 더하여 글그룹 설정
				}
				String sql = "insert into NS_qa values(NS_qa_seq.nextval, ?, ?,sysdate, 0, ?, ?, ?, ?)";

				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, bean.getId());
				pstmt.setString(2, bean.getQa_subject());
				pstmt.setInt(3, qa_ref);
				pstmt.setInt(4, qa_re_step);
				pstmt.setInt(5, qa_re_level);
				pstmt.setString(6, bean.getQa_content());

				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public int getAllQAcount() {
			getConnection();

			int count = 0;
			try {
				String sql = "select count(*) from NS_qa";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					count = rs.getInt(1);
				}
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return count;
		}

		// QA 페이지 카운트
		public Vector<BoardBean> getAllQABoard(int start, int end) {

			Vector<BoardBean> v = new Vector<BoardBean>();

			getConnection();

			try {
				String sql = "select * from (select A.*, Rownum Rnum from (select * from NS_qa order by qa_ref desc, qa_re_step asc)A) where Rnum >= ? and Rnum <=?";

				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, start);
				pstmt.setInt(2, end);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					BoardBean bean = new BoardBean();
					bean.setQa_num(rs.getInt(1));// sequence number
					bean.setId(rs.getString(2));
					bean.setQa_subject(rs.getString(3));
					bean.setQa_reg_date(rs.getDate(4).toString());
					bean.setQa_readCount(rs.getInt(5));
					bean.setQa_ref(rs.getInt(6));
					bean.setQa_re_step(rs.getInt(7));
					bean.setQa_re_level(rs.getInt(8));
					bean.setQa_content(rs.getString(9));

					v.add(bean);
				}

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return v;
		}

		public BoardBean getQAInfo(int qa_num) {
			BoardBean bean = new BoardBean();
			getConnection();

			try {

				String readsql = "update NS_qa set qa_readCount = qa_readCount + 1 where qa_num=?";
				pstmt = conn.prepareStatement(readsql);
				pstmt.setInt(1, qa_num);
				pstmt.executeUpdate();

				String sql = "select * from NS_qa where qa_num=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, qa_num);
				rs = pstmt.executeQuery();
				if (rs.next()) {

					bean.setQa_num(rs.getInt(1));// sequence number
					bean.setId(rs.getString(2));
					bean.setQa_subject(rs.getString(3));
					bean.setQa_reg_date(rs.getDate(4).toString());
					bean.setQa_readCount(rs.getInt(5));
					bean.setQa_ref(rs.getInt(6));
					bean.setQa_re_step(rs.getInt(7));
					bean.setQa_re_level(rs.getInt(8));
					bean.setQa_content(rs.getString(9));

				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return bean;
		}

		public BoardBean getQAInfoSubject(int qa_num) {
			BoardBean bean = new BoardBean();
			getConnection();

			try {
				String sql = "select * from NS_qa where qa_num=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, qa_num);
				rs = pstmt.executeQuery();
				if (rs.next()) {

					bean.setQa_num(rs.getInt(1));// sequence number
					bean.setId(rs.getString(2));
					bean.setQa_subject(rs.getString(3));
					bean.setQa_reg_date(rs.getDate(4).toString());
					bean.setQa_readCount(rs.getInt(5));
					bean.setQa_ref(rs.getInt(6));
					bean.setQa_re_step(rs.getInt(7));
					bean.setQa_re_level(rs.getInt(8));
					bean.setQa_content(rs.getString(9));

				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return bean;
		}
		public void reWriteQA(BoardBean bean) {
			int qa_ref = bean.getQa_ref();
			int qa_re_step = bean.getQa_re_step();
			int qa_re_level = bean.getQa_re_level();

			getConnection();

			try {
				// 부모 글 보다 더 큰 re_level의 값을 모두 1씩 증가시켜줍니다.
				String levelsql = "update NS_qa set qa_re_level = qa_re_level + 1 where qa_ref=? and qa_re_level > ?";

				pstmt = conn.prepareStatement(levelsql);
				pstmt.setInt(1, qa_ref);
				pstmt.setInt(2, qa_re_level);
				pstmt.executeUpdate();

				// 답변글 데이터 저장
				String sql = "insert into NS_qa values(NS_qa_seq.nextval, ?, ?,sysdate, 0, ?, ?, ?, ?)";
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, bean.getId());
				pstmt.setString(2, bean.getQa_subject());
				pstmt.setInt(3, qa_ref); // 부모의 trf값을 넣어줍니다.
				pstmt.setInt(4, qa_re_step + 1); // 답글이기에 부모 글 re_step에 1을 넣어줍니다.
				pstmt.setInt(5, qa_re_level + 1);
				pstmt.setString(6, bean.getQa_content());

				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		public BoardBean getOneUpdateOA(int qa_num) {
			BoardBean bean = new BoardBean();
			getConnection();

			try {
				String sql = "select * from NS_qa where qa_num =?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, qa_num);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					bean.setQa_num(rs.getInt(1));// sequence number
					bean.setId(rs.getString(2));
					bean.setQa_subject(rs.getString(3));
					bean.setQa_reg_date(rs.getDate(4).toString());
					bean.setQa_readCount(rs.getInt(5));
					bean.setQa_ref(rs.getInt(6));
					bean.setQa_re_step(rs.getInt(7));
					bean.setQa_re_level(rs.getInt(8));
					bean.setQa_content(rs.getString(9));
				}

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

			return bean;
		}

		public void updateQA(BoardBean bean) {
			getConnection();

			try {
				String sql = "update NS_qa set qa_subject =?, qa_content=? where qa_num =?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, bean.getQa_subject());
				pstmt.setString(2, bean.getQa_content());
				pstmt.setInt(3, bean.getQa_num());

				pstmt.executeUpdate();

				conn.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void DeleteQA(int qa_num) {
			getConnection();
			try {
				String sql = "delete from NS_qa where qa_num = ?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, qa_num);
				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public String getQAMember(String id, int qa_num) {
			String result = ""; // 처음이면 회원 없음.

			getConnection(); // DB연결

			try {
				String sql = "select id from NS_qa where id=?and qa_num=?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, id);
				pstmt.setInt(2, qa_num);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					result = rs.getString(1); // 0또는 1 값이 저장됩니다.
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return result;
		}

//커뮤니티
		public int getAllCOMcount() {
			getConnection();

			int count = 0;
			try {
				String sql = "select count(*) from NS_community";
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();

				if (rs.next()) {
					count = rs.getInt(1);
				}
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return count;
		}

	// 커뮤니티 페이지 카운트
		public Vector<BoardBean> getAllCOMBoard(int start, int end) {

			Vector<BoardBean> v = new Vector<BoardBean>();

			getConnection();

			try {
				String sql = "select * from (select A.*, Rownum Rnum from (select * from NS_community order by com_ref desc, com_re_step asc)A) where Rnum >= ? and Rnum <=?";

				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, start);
				pstmt.setInt(2, end);
				rs = pstmt.executeQuery();

				while (rs.next()) {
					BoardBean bean = new BoardBean();
					bean.setCom_num(rs.getInt(1));// sequence number
					bean.setId(rs.getString(2));
					bean.setCom_subject(rs.getString(3));
					bean.setCom_reg_date(rs.getDate(4).toString());
					bean.setCom_ref(rs.getInt(5));
					bean.setCom_readCount(rs.getInt(6));
					bean.setCom_content(rs.getString(7));
					bean.setCom_re_step(rs.getInt(8));
					bean.setCom_re_level(rs.getInt(9));

					v.add(bean);
				}

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return v;
		}

		public void insertCom(BoardBean bean) {
			getConnection();

			int com_ref = 0; // 글그룹 = 쿼리를 실행하여 가장 큰 ref 값을 가져오고 +1을 더해줍니다.
			int com_re_step = 1; // 새 글 일 때 = 부모글이기에
			int com_re_level = 1;
			try {
				String refsql = "select max(com_ref) from NS_community";
				pstmt = conn.prepareStatement(refsql);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					com_ref = rs.getInt(1) + 1; // 최대값에 +1을 더하여 글그룹 설정
				}
				String sql = "insert into NS_community values(NS_community_seq.nextval, ?, ?,sysdate, ?, 0, ?, ?, ?)";

				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, bean.getId());
				pstmt.setString(2, bean.getCom_subject());
				pstmt.setInt(3, com_ref);
				pstmt.setString(4, bean.getCom_content());
				pstmt.setInt(5, com_re_step);
				pstmt.setInt(6, com_re_level);

				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
//커뮤니티글 상세보기
		public BoardBean getComInfo(int com_num) {
			BoardBean bean = new BoardBean();
			getConnection();

			try {

				String readsql = "update NS_community set com_readCount = com_readCount + 1 where com_num=?";
				pstmt = conn.prepareStatement(readsql);
				pstmt.setInt(1, com_num);
				pstmt.executeUpdate();

				String sql = "select * from NS_community where com_num=?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, com_num);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					bean.setCom_num(rs.getInt(1));// sequence number
					bean.setId(rs.getString(2));
					bean.setCom_subject(rs.getString(3));
					bean.setCom_reg_date(rs.getDate(4).toString());
					bean.setCom_ref(rs.getInt(5));
					bean.setCom_readCount(rs.getInt(6));
					bean.setCom_content(rs.getString(7));
					bean.setCom_re_step(rs.getInt(8));
					bean.setCom_re_level(rs.getInt(9));

				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return bean;
		}

		public String getComMember(String id, int com_num) {
			String result = ""; // 처음이면 회원 없음.

			getConnection(); // DB연결

			try {
				String sql = "select id from NS_community where id=?and com_num=?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, id);
				pstmt.setInt(2, com_num);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					result = rs.getString(1); // 0또는 1 값이 저장됩니다.
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return result;
		}
//수정
		public void CommunityUpdate(BoardBean cbean) {
			getConnection();
			
			try {
				String sql = "update NS_community set com_subject=?, com_content=? where com_num=?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, cbean.getCom_subject());
				pstmt.setString(2, cbean.getCom_content());
				pstmt.setInt(3, cbean.getCom_num());

				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
//삭제
		public void CommunityDelete(int com_num) {
			getConnection();
			try {
				String csql = "delete from NS_comment where com_num = ?";
				pstmt = conn.prepareStatement(csql);
				pstmt.setInt(1, com_num);
				pstmt.executeUpdate();
				
				String sql = "delete from NS_community where com_num = ?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, com_num);
				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
// 댓글

		public void insertComment(BoardBean bean) {
			getConnection();

			int comment_ref = 0; // 글그룹 = 쿼리를 실행하여 가장 큰 ref 값을 가져오고 +1을 더해줍니다.
			int comment_re_step = 1; // 새 글 일 때 = 부모글이기에
			int comment_re_level = 1;
			try {
				String refsql = "select max(comment_ref) from NS_comment";
				pstmt = conn.prepareStatement(refsql);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					comment_ref = rs.getInt(1) + 1; // 최대값에 +1을 더하여 글그룹 설정
				}
				String sql = "insert into NS_comment values(NS_comment_seq.nextval, ?, ?,?,?,sysdate, ?, ?)";

				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, bean.getCom_num());
				pstmt.setString(2, bean.getId());
				pstmt.setInt(3, comment_ref);
				pstmt.setString(4, bean.getComment_content());
				pstmt.setInt(5, comment_re_step);
				pstmt.setInt(6, comment_re_level);

				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public Vector<BoardBean> getAllComment(int com_num) {
			Vector<BoardBean> v = new Vector<BoardBean>();
			getConnection();
			try {
				String sql = "select * from NS_comment where com_num=? order by comment_ref desc";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, com_num);

				rs = pstmt.executeQuery();
				while (rs.next()) {
					BoardBean bean = new BoardBean();
					bean.setComment_num(rs.getInt(1));
					bean.setCom_num(rs.getInt(2));
					bean.setId(rs.getString(3));
					bean.setComment_ref(rs.getInt(4));
					bean.setComment_content(rs.getString(5));
					bean.setComment_time(rs.getString(6).toString());
					bean.setComment_re_step(rs.getInt(7));
					bean.setComment_re_level(rs.getInt(8));
					v.add(bean);
				}
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return v;
		}

		public String getCommentMember(String id) {
			String result = ""; // 처음이면 회원 없음.

			getConnection(); // DB연결

			try {
				String sql = "select id from NS_comment where id=?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, id);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					result = rs.getString(1); // 0또는 1 값이 저장됩니다.
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return result;
		}
//댓글 가져오기
		public String getCommentMember(String id, int comment_num) {
			String result = ""; // 처음이면 회원 없음.

			getConnection(); // DB연결

			try {
				String sql = "select id from NS_comment where id=?and comment_num=?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setString(1, id);
				pstmt.setInt(2, comment_num);

				rs = pstmt.executeQuery();

				if (rs.next()) {
					result = rs.getString(1); // 0또는 1 값이 저장됩니다.
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return result;
		}
//댓글 삭제
		public void CommentDelete(int comment_num) {
			getConnection();
			try {
				String sql = "delete from NS_comment where comment_num = ?";
				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, comment_num);
				pstmt.executeUpdate();

				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		
		
		
		
	}